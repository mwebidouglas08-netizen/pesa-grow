/**
 * PESA GROW — Production Backend
 * Express + SQLite + JWT + M-Pesa Daraja STK Push
 */
'use strict';
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const Database = require('better-sqlite3');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { v4: uuid } = require('uuid');
const multer = require('multer');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT = process.env.JWT_SECRET || 'pesagrow_dev_secret_change_me';
const MPESA_BASE = (process.env.MPESA_ENV || 'sandbox') === 'live'
  ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke';

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
const upload = multer({ dest: uploadsDir, limits: { fileSize: 5 * 1024 * 1024 } });

app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadsDir));
app.use('/api', rateLimit({ windowMs: 60000, max: 150 }));

const DB = new Database(process.env.DB_PATH || './pesagrow.db');
DB.pragma('journal_mode = WAL');
DB.pragma('foreign_keys = ON');

DB.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, firstName TEXT NOT NULL, lastName TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL, phone TEXT, password TEXT NOT NULL,
  role TEXT DEFAULT 'user', status TEXT DEFAULT 'active',
  balance REAL DEFAULT 0, totalDeposited REAL DEFAULT 0,
  totalInvested REAL DEFAULT 0, totalProfits REAL DEFAULT 0,
  totalWithdrawn REAL DEFAULT 0, refCode TEXT UNIQUE,
  referredBy TEXT, kycStatus TEXT DEFAULT 'none', kycDoc TEXT,
  createdAt TEXT NOT NULL, lastLogin TEXT
);
CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, roi REAL NOT NULL,
  period INTEGER NOT NULL, minAmount REAL NOT NULL, maxAmount REAL NOT NULL,
  referralBonus REAL DEFAULT 5, color TEXT DEFAULT '#10b981',
  description TEXT, popular INTEGER DEFAULT 0, active INTEGER DEFAULT 1,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS investments (
  id TEXT PRIMARY KEY, userId TEXT NOT NULL, planId TEXT NOT NULL,
  planName TEXT, amount REAL NOT NULL, roi REAL NOT NULL,
  period INTEGER NOT NULL, earned REAL DEFAULT 0,
  status TEXT DEFAULT 'active', startDate TEXT NOT NULL,
  endDate TEXT NOT NULL, lastCredited TEXT
);
CREATE TABLE IF NOT EXISTS deposits (
  id TEXT PRIMARY KEY, userId TEXT NOT NULL, amount REAL NOT NULL,
  method TEXT DEFAULT 'M-Pesa', status TEXT DEFAULT 'pending',
  mpesaCheckoutId TEXT, mpesaReceiptNo TEXT, mpesaPhone TEXT,
  proofNote TEXT, proofFile TEXT, reviewedBy TEXT, reviewedAt TEXT,
  rejectionReason TEXT, createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS withdrawals (
  id TEXT PRIMARY KEY, userId TEXT NOT NULL, amount REAL NOT NULL,
  fee REAL DEFAULT 0, net REAL NOT NULL, method TEXT NOT NULL,
  address TEXT NOT NULL, status TEXT DEFAULT 'pending',
  reviewedBy TEXT, reviewedAt TEXT, rejectionReason TEXT, createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY, userId TEXT NOT NULL, type TEXT NOT NULL,
  amount REAL NOT NULL, description TEXT, status TEXT DEFAULT 'completed',
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS referrals (
  id TEXT PRIMARY KEY, referrerId TEXT NOT NULL, refereeId TEXT NOT NULL,
  earnings REAL DEFAULT 0, createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, userId TEXT NOT NULL, message TEXT NOT NULL,
  type TEXT DEFAULT 'info', read INTEGER DEFAULT 0, createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS mpesa_logs (
  id TEXT PRIMARY KEY, checkoutId TEXT, phone TEXT, amount REAL,
  resultCode TEXT, resultDesc TEXT, receiptNo TEXT, rawPayload TEXT, processedAt TEXT
);
`);

const now = () => new Date().toISOString();
const genRef = () => 'PG' + Math.random().toString(36).slice(2,7).toUpperCase();
const kes = n => 'KES ' + (+n||0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,',');
const getSetting = k => DB.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value;
const setSetting = (k,v) => DB.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)').run(k,String(v));

function addTx(userId, type, amount, desc, status='completed') {
  DB.prepare('INSERT INTO transactions(id,userId,type,amount,description,status,createdAt) VALUES(?,?,?,?,?,?,?)')
    .run(uuid(),userId,type,amount,desc,status,now());
}
function addNotif(userId, message, type='info') {
  DB.prepare('INSERT INTO notifications(id,userId,message,type,read,createdAt) VALUES(?,?,?,?,0,?)')
    .run(uuid(),userId,message,type,now());
}

// Seed
(function() {
  const t = now();
  if (!DB.prepare("SELECT id FROM users WHERE role='admin'").get()) {
    DB.prepare(`INSERT INTO users(id,firstName,lastName,email,phone,password,role,status,refCode,createdAt,lastLogin) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .run(uuid(),'Admin','PesaGrow','admin@pesagrow.co.ke',process.env.ADMIN_PHONE||'0796820013',
        bcrypt.hashSync('Admin@2024',10),'admin','active','PGADMIN',t,t);
  }
  if (!DB.prepare('SELECT id FROM plans LIMIT 1').get()) {
    const ins = DB.prepare(`INSERT INTO plans(id,name,roi,period,minAmount,maxAmount,referralBonus,color,description,popular,active,createdAt) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)`);
    [
      ['Starter',3,7,1000,9999,'#22d3ee',5,'Perfect entry point for new investors',0],
      ['Silver',5,14,10000,49999,'#94a3b8',5,'Consistent returns for growing portfolios',0],
      ['Gold',7,21,50000,199999,'#f59e0b',7,'High-yield plan for serious investors',1],
      ['Platinum',10,30,200000,9999999,'#a855f7',10,'Elite returns for maximum growth',0],
    ].forEach(p => ins.run(uuid(),p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],t));
  }
  const defs = { siteName:'Pesa Grow',sitePhone:'0796820013',siteEmail:'support@pesagrow.co.ke',
    currency:'KES',minDeposit:1000,minWithdraw:500,withdrawFee:2,referralRate:5,welcomeBonus:0,
    mpesaTill:process.env.MPESA_SHORTCODE||'174379',mpesaName:'PESA GROW LTD',
    btcAddress:'1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2',usdtAddress:'TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7' };
  for (const [k,v] of Object.entries(defs)) if (!getSetting(k)) setSetting(k,v);
})();

function auth(req,res,next){ const t=req.headers.authorization?.split(' ')[1]; if(!t) return res.status(401).json({error:'Unauthorized'}); try{req.user=jwt.verify(t,JWT);next();}catch{res.status(401).json({error:'Token invalid'});}}
function adminAuth(req,res,next){ auth(req,res,()=>req.user.role==='admin'?next():res.status(403).json({error:'Admin only'})); }

// M-Pesa helpers
async function mpesaToken() {
  const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
  const {data} = await axios.get(`${MPESA_BASE}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${auth}`}});
  return data.access_token;
}
function mpesaPassword() {
  const ts = new Date().toISOString().replace(/[^0-9]/g,'').slice(0,14);
  return { password: Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${ts}`).toString('base64'), timestamp: ts };
}
function sanitizePhone(p) {
  p = String(p).replace(/\D/g,'');
  if(p.startsWith('0')) p='254'+p.slice(1);
  if(!p.startsWith('254')) p='254'+p;
  return p;
}

// AUTH
app.post('/api/auth/register', async(req,res) => {
  try {
    const {firstName,lastName,email,phone,password,refCode} = req.body;
    if(!firstName||!lastName||!email||!password) return res.status(400).json({error:'All fields required'});
    if(password.length<8) return res.status(400).json({error:'Password must be 8+ characters'});
    if(DB.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(400).json({error:'Email already registered'});
    const bonus = parseFloat(getSetting('welcomeBonus')||0);
    const id = uuid();
    DB.prepare(`INSERT INTO users(id,firstName,lastName,email,phone,password,role,status,balance,totalDeposited,refCode,createdAt,lastLogin) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(id,firstName,lastName,email,phone||'',bcrypt.hashSync(password,10),'user','active',bonus,bonus,genRef(),now(),now());
    if(refCode){
      const referrer=DB.prepare('SELECT id FROM users WHERE refCode=?').get(refCode);
      if(referrer){DB.prepare('UPDATE users SET referredBy=? WHERE id=?').run(referrer.id,id);DB.prepare('INSERT INTO referrals(id,referrerId,refereeId,earnings,createdAt) VALUES(?,?,?,0,?)').run(uuid(),referrer.id,id,now());}
    }
    if(bonus>0) addTx(id,'bonus',bonus,'Welcome bonus');
    const user = DB.prepare('SELECT * FROM users WHERE id=?').get(id);
    const token = jwt.sign({id,role:'user'},JWT,{expiresIn:'7d'});
    const {password:_,...safe} = user;
    res.json({token,user:safe});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/auth/login',(req,res) => {
  try {
    const {email,password} = req.body;
    const user = DB.prepare('SELECT * FROM users WHERE email=?').get(email);
    if(!user) return res.status(400).json({error:'No account found with this email'});
    if(!bcrypt.compareSync(password,user.password)) return res.status(400).json({error:'Incorrect password'});
    if(user.status==='suspended') return res.status(403).json({error:'Account suspended. Contact 0796820013'});
    DB.prepare('UPDATE users SET lastLogin=? WHERE id=?').run(now(),user.id);
    const token = jwt.sign({id:user.id,role:user.role},JWT,{expiresIn:'7d'});
    const {password:_,...safe} = user;
    res.json({token,user:safe});
  } catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/auth/me',auth,(req,res) => {
  const user = DB.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if(!user) return res.status(404).json({error:'Not found'});
  const {password:_,...safe} = user;
  res.json(safe);
});

// M-PESA STK PUSH
app.post('/api/mpesa/stk-push',auth,async(req,res) => {
  try {
    const {amount,phone} = req.body;
    const minDep = parseFloat(getSetting('minDeposit')||1000);
    if(!amount||amount<minDep) return res.status(400).json({error:`Minimum deposit is ${kes(minDep)}`});
    if(!phone) return res.status(400).json({error:'Phone number required'});
    const depId = uuid(); const mpPhone = sanitizePhone(phone);
    DB.prepare(`INSERT INTO deposits(id,userId,amount,method,status,mpesaPhone,createdAt) VALUES(?,?,?,'M-Pesa STK','pending',?,?)`)
      .run(depId,req.user.id,amount,mpPhone,now());
    addTx(req.user.id,'deposit',amount,`M-Pesa STK #${depId.slice(-6)}`,'pending');
    const token = await mpesaToken();
    const {password,timestamp} = mpesaPassword();
    const {data} = await axios.post(`${MPESA_BASE}/mpesa/stkpush/v1/processrequest`,{
      BusinessShortCode:process.env.MPESA_SHORTCODE, Password:password, Timestamp:timestamp,
      TransactionType:process.env.MPESA_TRANSACTION_TYPE||'CustomerBuyGoodsOnline',
      Amount:Math.ceil(amount), PartyA:mpPhone, PartyB:process.env.MPESA_SHORTCODE,
      PhoneNumber:mpPhone, CallBackURL:`${process.env.BASE_URL}/api/mpesa/callback`,
      AccountReference:'PesaGrow', TransactionDesc:`Deposit #${depId.slice(-6)}`,
    },{headers:{Authorization:`Bearer ${token}`}});
    if(data.ResponseCode!=='0') return res.status(400).json({error:data.errorMessage||'STK Push failed'});
    DB.prepare('UPDATE deposits SET mpesaCheckoutId=? WHERE id=?').run(data.CheckoutRequestID,depId);
    addNotif(req.user.id,`M-Pesa prompt sent to ${phone}. Enter your PIN to confirm.`,'info');
    res.json({success:true,depositId:depId,checkoutRequestId:data.CheckoutRequestID,message:data.CustomerMessage});
  } catch(e){console.error('STK:',e.response?.data||e.message); res.status(500).json({error:'M-Pesa service error. Try manual deposit.'});}
});

app.get('/api/mpesa/status/:cid',auth,async(req,res) => {
  const dep = DB.prepare('SELECT * FROM deposits WHERE mpesaCheckoutId=? AND userId=?').get(req.params.cid,req.user.id);
  if(!dep) return res.status(404).json({error:'Not found'});
  if(dep.status!=='pending') return res.json({status:dep.status,receiptNo:dep.mpesaReceiptNo});
  try {
    const token = await mpesaToken(); const {password,timestamp} = mpesaPassword();
    const {data} = await axios.post(`${MPESA_BASE}/mpesa/stkpushquery/v1/query`,
      {BusinessShortCode:process.env.MPESA_SHORTCODE,Password:password,Timestamp:timestamp,CheckoutRequestID:req.params.cid},
      {headers:{Authorization:`Bearer ${token}`}});
    const c = String(data.ResultCode);
    res.json({status: c==='0'?'approved':c==='1032'?'cancelled':'pending'});
  } catch { res.json({status:dep.status}); }
});

app.post('/api/mpesa/callback',(req,res) => {
  res.json({ResultCode:0,ResultDesc:'Accepted'});
  try {
    const cb = req.body?.Body?.stkCallback; if(!cb) return;
    const id=cb.CheckoutRequestID, code=cb.ResultCode;
    let receiptNo,amount,phone;
    if(code===0&&cb.CallbackMetadata?.Item){
      const get = n=>cb.CallbackMetadata.Item.find(i=>i.Name===n)?.Value;
      receiptNo=get('MpesaReceiptNumber'); amount=get('Amount'); phone=get('PhoneNumber');
    }
    DB.prepare(`INSERT INTO mpesa_logs(id,checkoutId,phone,amount,resultCode,resultDesc,receiptNo,rawPayload,processedAt) VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(uuid(),id,phone,amount,code,cb.ResultDesc,receiptNo,JSON.stringify(req.body),now());
    const dep = DB.prepare('SELECT * FROM deposits WHERE mpesaCheckoutId=?').get(id);
    if(!dep) return;
    if(code===0){
      const credit = amount||dep.amount;
      DB.prepare(`UPDATE deposits SET status='approved',mpesaReceiptNo=?,mpesaPhone=?,reviewedAt=? WHERE id=?`).run(receiptNo,phone,now(),dep.id);
      DB.prepare('UPDATE users SET balance=balance+?,totalDeposited=totalDeposited+? WHERE id=?').run(credit,credit,dep.userId);
      DB.prepare(`UPDATE transactions SET status='completed',description=? WHERE userId=? AND type='deposit' AND status='pending'`).run(`M-Pesa ${receiptNo}`,dep.userId);
      addNotif(dep.userId,`✅ Deposit of ${kes(credit)} confirmed! Receipt: ${receiptNo}`,'success');
      const user = DB.prepare('SELECT * FROM users WHERE id=?').get(dep.userId);
      if(user.referredBy){
        const ref = DB.prepare('SELECT * FROM referrals WHERE refereeId=?').get(dep.userId);
        if(ref){const comm=credit*(parseFloat(getSetting('referralRate')||5)/100);DB.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(comm,user.referredBy);DB.prepare('UPDATE referrals SET earnings=earnings+? WHERE id=?').run(comm,ref.id);addTx(user.referredBy,'referral',comm,`Commission from ${user.firstName}`);addNotif(user.referredBy,`💰 Referral bonus: ${kes(comm)} from ${user.firstName}!`,'success');}
      }
    } else {
      DB.prepare(`UPDATE deposits SET status='failed',rejectionReason=?,reviewedAt=? WHERE id=?`).run(cb.ResultDesc,now(),dep.id);
      addNotif(dep.userId,`❌ Payment failed: ${cb.ResultDesc}. Try again.`,'error');
    }
  } catch(e){console.error('Callback:',e.message);}
});

// USER ROUTES
app.get('/api/user/dashboard',auth,(req,res) => {
  const u = DB.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if(!u) return res.status(404).json({error:'Not found'});
  const {password:_,...safe} = u;
  res.json({
    user:safe,
    investments:DB.prepare('SELECT * FROM investments WHERE userId=? ORDER BY startDate DESC').all(u.id),
    transactions:DB.prepare('SELECT * FROM transactions WHERE userId=? ORDER BY createdAt DESC LIMIT 30').all(u.id),
    deposits:DB.prepare('SELECT * FROM deposits WHERE userId=? ORDER BY createdAt DESC LIMIT 20').all(u.id),
    withdrawals:DB.prepare('SELECT * FROM withdrawals WHERE userId=? ORDER BY createdAt DESC LIMIT 20').all(u.id),
    referrals:DB.prepare('SELECT * FROM referrals WHERE referrerId=?').all(u.id),
    notifications:DB.prepare('SELECT * FROM notifications WHERE userId=? ORDER BY createdAt DESC LIMIT 25').all(u.id),
    unreadCount:DB.prepare('SELECT COUNT(*) c FROM notifications WHERE userId=? AND read=0').get(u.id).c,
  });
});

app.post('/api/user/invest',auth,(req,res) => {
  try {
    const {planId,amount} = req.body;
    const user = DB.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    const plan = DB.prepare('SELECT * FROM plans WHERE id=? AND active=1').get(planId);
    if(!plan) return res.status(400).json({error:'Plan not available'});
    if(amount<plan.minAmount) return res.status(400).json({error:`Minimum is ${kes(plan.minAmount)}`});
    if(amount>plan.maxAmount) return res.status(400).json({error:`Maximum is ${kes(plan.maxAmount)}`});
    if(user.balance<amount) return res.status(400).json({error:'Insufficient balance. Please deposit first.'});
    const id=uuid(), end=new Date(Date.now()+plan.period*86400000).toISOString();
    DB.prepare(`INSERT INTO investments(id,userId,planId,planName,amount,roi,period,earned,status,startDate,endDate,lastCredited) VALUES(?,?,?,?,?,?,?,0,'active',?,?,?)`)
      .run(id,user.id,plan.id,plan.name,amount,plan.roi,plan.period,now(),end,now());
    DB.prepare('UPDATE users SET balance=balance-?,totalInvested=totalInvested+? WHERE id=?').run(amount,amount,user.id);
    addTx(user.id,'investment',amount,`${plan.name} Plan`);
    addNotif(user.id,`🚀 ${plan.name} activated! Earning ${plan.roi}% daily for ${plan.period} days.`,'success');
    res.json({success:true,investmentId:id});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/user/deposit/manual',auth,(req,res) => {
  try {
    const {amount,method,proofNote} = req.body;
    const minDep=parseFloat(getSetting('minDeposit')||1000);
    if(!amount||amount<minDep) return res.status(400).json({error:`Minimum is ${kes(minDep)}`});
    if(!proofNote) return res.status(400).json({error:'Provide your M-Pesa transaction code'});
    const id=uuid();
    DB.prepare(`INSERT INTO deposits(id,userId,amount,method,status,proofNote,createdAt) VALUES(?,?,?,?,?,?,?)`)
      .run(id,req.user.id,amount,method||'M-Pesa','pending',proofNote,now());
    addTx(req.user.id,'deposit',amount,'Manual deposit','pending');
    addNotif(req.user.id,`⏳ Deposit of ${kes(amount)} submitted. Admin confirms within 30 mins.`,'info');
    res.json({success:true,depositId:id});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/user/withdraw',auth,(req,res) => {
  try {
    const {amount,method,address} = req.body;
    const user=DB.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    const minWd=parseFloat(getSetting('minWithdraw')||500);
    const fee=amount*(parseFloat(getSetting('withdrawFee')||2)/100);
    const net=amount-fee;
    if(!amount||amount<minWd) return res.status(400).json({error:`Minimum is ${kes(minWd)}`});
    if(!address) return res.status(400).json({error:'Provide M-Pesa number or account'});
    if(user.balance<amount) return res.status(400).json({error:'Insufficient balance'});
    const id=uuid();
    DB.prepare('UPDATE users SET balance=balance-? WHERE id=?').run(amount,user.id);
    DB.prepare(`INSERT INTO withdrawals(id,userId,amount,fee,net,method,address,status,createdAt) VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(id,user.id,amount,fee,net,method||'M-Pesa',address,'pending',now());
    addTx(user.id,'withdrawal',amount,'Withdrawal pending','pending');
    addNotif(user.id,`⏳ Withdrawal of ${kes(amount)} submitted. Processing within 2 hours.`,'info');
    res.json({success:true,withdrawalId:id,net,fee});
  } catch(e){res.status(500).json({error:e.message});}
});

app.put('/api/user/profile',auth,(req,res) => {
  const {firstName,lastName,phone}=req.body;
  DB.prepare('UPDATE users SET firstName=COALESCE(?,firstName),lastName=COALESCE(?,lastName),phone=COALESCE(?,phone) WHERE id=?')
    .run(firstName||null,lastName||null,phone||null,req.user.id);
  res.json({success:true});
});
app.put('/api/user/password',auth,(req,res) => {
  const {currentPassword,newPassword}=req.body;
  const user=DB.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if(!bcrypt.compareSync(currentPassword,user.password)) return res.status(400).json({error:'Current password incorrect'});
  if((newPassword||'').length<8) return res.status(400).json({error:'New password must be 8+ characters'});
  DB.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(newPassword,10),req.user.id);
  res.json({success:true});
});
app.post('/api/user/kyc',auth,upload.single('document'),(req,res) => {
  if(!req.file) return res.status(400).json({error:'No document uploaded'});
  DB.prepare("UPDATE users SET kycStatus='submitted',kycDoc=? WHERE id=?").run(req.file.filename,req.user.id);
  addNotif(req.user.id,'📋 KYC document submitted. Under review within 24 hours.','info');
  res.json({success:true});
});
app.get('/api/user/notifications',auth,(req,res) => res.json(DB.prepare('SELECT * FROM notifications WHERE userId=? ORDER BY createdAt DESC LIMIT 30').all(req.user.id)));
app.put('/api/user/notifications/read',auth,(req,res) => { DB.prepare('UPDATE notifications SET read=1 WHERE userId=?').run(req.user.id); res.json({success:true}); });

// PUBLIC
app.get('/api/plans',(req,res) => res.json(DB.prepare('SELECT * FROM plans WHERE active=1 ORDER BY minAmount ASC').all()));
app.get('/api/settings/public',(req,res) => {
  const keys=['siteName','sitePhone','siteEmail','currency','minDeposit','minWithdraw','withdrawFee','referralRate','mpesaTill','mpesaName','btcAddress','usdtAddress'];
  res.json(Object.fromEntries(DB.prepare(`SELECT key,value FROM settings WHERE key IN (${keys.map(()=>'?').join(',')})`).all(...keys).map(r=>[r.key,r.value])));
});

// ADMIN
app.get('/api/admin/stats',adminAuth,(req,res) => res.json({
  totalMembers: DB.prepare("SELECT COUNT(*) c FROM users WHERE role!='admin'").get().c,
  activeInvestors: DB.prepare("SELECT COUNT(DISTINCT userId) c FROM investments WHERE status='active'").get().c,
  pendingDeposits: DB.prepare("SELECT COUNT(*) c FROM deposits WHERE status='pending'").get().c,
  pendingWithdrawals: DB.prepare("SELECT COUNT(*) c FROM withdrawals WHERE status='pending'").get().c,
  totalDeposited: DB.prepare("SELECT COALESCE(SUM(amount),0) s FROM deposits WHERE status='approved'").get().s,
  totalWithdrawn: DB.prepare("SELECT COALESCE(SUM(net),0) s FROM withdrawals WHERE status='approved'").get().s,
  totalInvested: DB.prepare("SELECT COALESCE(SUM(amount),0) s FROM investments").get().s,
  totalProfitPaid: DB.prepare("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE type='profit'").get().s,
  recentMembers: DB.prepare("SELECT id,firstName,lastName,email,balance,status,createdAt FROM users WHERE role!='admin' ORDER BY createdAt DESC LIMIT 5").all(),
}));
app.get('/api/admin/members',adminAuth,(req,res) => res.json(DB.prepare("SELECT id,firstName,lastName,email,phone,balance,totalDeposited,totalInvested,totalProfits,totalWithdrawn,status,refCode,kycStatus,createdAt,lastLogin FROM users WHERE role!='admin' ORDER BY createdAt DESC").all()));
app.put('/api/admin/members/:id',adminAuth,(req,res) => {
  const p=req.body;
  DB.prepare(`UPDATE users SET firstName=COALESCE(?,firstName),lastName=COALESCE(?,lastName),email=COALESCE(?,email),phone=COALESCE(?,phone),balance=COALESCE(?,balance),status=COALESCE(?,status),kycStatus=COALESCE(?,kycStatus) WHERE id=?`)
    .run(p.firstName||null,p.lastName||null,p.email||null,p.phone||null,p.balance!=null?p.balance:null,p.status||null,p.kycStatus||null,req.params.id);
  res.json({success:true});
});
app.post('/api/admin/members',adminAuth,async(req,res) => {
  const {firstName,lastName,email,phone,password,balance}=req.body;
  if(!email||!password) return res.status(400).json({error:'Email and password required'});
  if(DB.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(400).json({error:'Email exists'});
  const id=uuid();
  DB.prepare(`INSERT INTO users(id,firstName,lastName,email,phone,password,role,status,balance,refCode,createdAt,lastLogin) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id,firstName||'',lastName||'',email,phone||'',bcrypt.hashSync(password,10),'user','active',balance||0,genRef(),now(),now());
  res.json({success:true,id});
});
app.get('/api/admin/deposits',adminAuth,(req,res) => res.json(DB.prepare(`SELECT d.*,u.firstName||' '||u.lastName userName,u.phone userPhone FROM deposits d LEFT JOIN users u ON d.userId=u.id ORDER BY d.createdAt DESC`).all()));
app.put('/api/admin/deposits/:id/approve',adminAuth,(req,res) => {
  const dep=DB.prepare('SELECT * FROM deposits WHERE id=?').get(req.params.id);
  if(!dep||dep.status!=='pending') return res.status(400).json({error:'Invalid'});
  DB.prepare("UPDATE deposits SET status='approved',reviewedBy=?,reviewedAt=? WHERE id=?").run(req.user.id,now(),dep.id);
  DB.prepare('UPDATE users SET balance=balance+?,totalDeposited=totalDeposited+? WHERE id=?').run(dep.amount,dep.amount,dep.userId);
  DB.prepare("UPDATE transactions SET status='completed' WHERE userId=? AND type='deposit' AND status='pending'").run(dep.userId);
  addNotif(dep.userId,`✅ Deposit of ${kes(dep.amount)} approved!`,'success');
  res.json({success:true});
});
app.put('/api/admin/deposits/:id/reject',adminAuth,(req,res) => {
  const dep=DB.prepare('SELECT * FROM deposits WHERE id=?').get(req.params.id);
  if(!dep) return res.status(404).json({error:'Not found'});
  DB.prepare("UPDATE deposits SET status='rejected',rejectionReason=?,reviewedBy=?,reviewedAt=? WHERE id=?").run(req.body.reason||'Rejected',req.user.id,now(),dep.id);
  addNotif(dep.userId,`❌ Deposit rejected. Reason: ${req.body.reason}`,'error');
  res.json({success:true});
});
app.get('/api/admin/withdrawals',adminAuth,(req,res) => res.json(DB.prepare(`SELECT w.*,u.firstName||' '||u.lastName userName,u.phone userPhone FROM withdrawals w LEFT JOIN users u ON w.userId=u.id ORDER BY w.createdAt DESC`).all()));
app.put('/api/admin/withdrawals/:id/approve',adminAuth,(req,res) => {
  const w=DB.prepare('SELECT * FROM withdrawals WHERE id=?').get(req.params.id);
  if(!w||w.status!=='pending') return res.status(400).json({error:'Invalid'});
  DB.prepare("UPDATE withdrawals SET status='approved',reviewedBy=?,reviewedAt=? WHERE id=?").run(req.user.id,now(),w.id);
  DB.prepare('UPDATE users SET totalWithdrawn=totalWithdrawn+? WHERE id=?').run(w.net,w.userId);
  DB.prepare("UPDATE transactions SET status='completed' WHERE userId=? AND type='withdrawal' AND status='pending'").run(w.userId);
  addNotif(w.userId,`✅ Withdrawal of ${kes(w.net)} sent to ${w.address}!`,'success');
  res.json({success:true});
});
app.put('/api/admin/withdrawals/:id/reject',adminAuth,(req,res) => {
  const w=DB.prepare('SELECT * FROM withdrawals WHERE id=?').get(req.params.id);
  if(!w) return res.status(404).json({error:'Not found'});
  DB.prepare("UPDATE withdrawals SET status='rejected',rejectionReason=?,reviewedBy=?,reviewedAt=? WHERE id=?").run(req.body.reason||'Rejected',req.user.id,now(),w.id);
  DB.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(w.amount,w.userId);
  addNotif(w.userId,`❌ Withdrawal rejected. ${kes(w.amount)} refunded.`,'error');
  res.json({success:true});
});
app.get('/api/admin/investments',adminAuth,(req,res) => res.json(DB.prepare(`SELECT i.*,u.firstName||' '||u.lastName userName FROM investments i LEFT JOIN users u ON i.userId=u.id ORDER BY i.startDate DESC`).all()));
app.get('/api/admin/transactions',adminAuth,(req,res) => res.json(DB.prepare('SELECT * FROM transactions ORDER BY createdAt DESC LIMIT 500').all()));
app.get('/api/admin/plans',adminAuth,(req,res) => res.json(DB.prepare('SELECT * FROM plans ORDER BY minAmount').all()));
app.post('/api/admin/plans',adminAuth,(req,res) => {
  const {name,roi,period,minAmount,maxAmount,referralBonus,color,description,popular}=req.body;
  if(!name||!roi||!period||!minAmount||!maxAmount) return res.status(400).json({error:'Required fields missing'});
  const id=uuid();
  DB.prepare(`INSERT INTO plans(id,name,roi,period,minAmount,maxAmount,referralBonus,color,description,popular,active,createdAt) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)`)
    .run(id,name,roi,period,minAmount,maxAmount,referralBonus||5,color||'#10b981',description||'',popular?1:0,now());
  res.json({success:true,id});
});
app.put('/api/admin/plans/:id',adminAuth,(req,res) => {
  const p=req.body;
  DB.prepare(`UPDATE plans SET name=COALESCE(?,name),roi=COALESCE(?,roi),period=COALESCE(?,period),minAmount=COALESCE(?,minAmount),maxAmount=COALESCE(?,maxAmount),referralBonus=COALESCE(?,referralBonus),color=COALESCE(?,color),description=COALESCE(?,description),active=COALESCE(?,active),popular=COALESCE(?,popular) WHERE id=?`)
    .run(p.name||null,p.roi||null,p.period||null,p.minAmount||null,p.maxAmount||null,p.referralBonus||null,p.color||null,p.description||null,p.active!=null?p.active:null,p.popular!=null?p.popular:null,req.params.id);
  res.json({success:true});
});
app.delete('/api/admin/plans/:id',adminAuth,(req,res) => { DB.prepare('DELETE FROM plans WHERE id=?').run(req.params.id); res.json({success:true}); });
app.get('/api/admin/settings',adminAuth,(req,res) => res.json(Object.fromEntries(DB.prepare('SELECT * FROM settings').all().map(r=>[r.key,r.value]))));
app.put('/api/admin/settings',adminAuth,(req,res) => { for(const [k,v] of Object.entries(req.body)) setSetting(k,v); res.json({success:true}); });
app.post('/api/admin/broadcast',adminAuth,(req,res) => {
  const {userId,message,type}=req.body;
  if(!message) return res.status(400).json({error:'Message required'});
  if(userId){addNotif(userId,message,type||'info');}
  else{DB.prepare("SELECT id FROM users WHERE role!='admin'").all().forEach(u=>addNotif(u.id,message,type||'info'));}
  res.json({success:true});
});
app.post('/api/admin/adjust-balance',adminAuth,(req,res) => {
  const {userId,amount,type,reason}=req.body;
  if(!userId||!amount||!type||!reason) return res.status(400).json({error:'All fields required'});
  DB.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(type==='credit'?amount:-amount,userId);
  addTx(userId,'bonus',amount,`Admin ${type}: ${reason}`);
  addNotif(userId,`Admin balance ${type}: ${kes(amount)} — ${reason}`,'info');
  res.json({success:true});
});
app.get('/api/admin/kyc',adminAuth,(req,res) => res.json(DB.prepare("SELECT id,firstName,lastName,email,phone,kycStatus,kycDoc,createdAt FROM users WHERE role!='admin' AND kycStatus!='none' ORDER BY createdAt DESC").all()));
app.put('/api/admin/kyc/:id',adminAuth,(req,res) => {
  DB.prepare('UPDATE users SET kycStatus=? WHERE id=?').run(req.body.status,req.params.id);
  addNotif(req.params.id,req.body.status==='verified'?'✅ KYC verified! Account fully verified.':'❌ KYC rejected. Please resubmit.',req.body.status==='verified'?'success':'error');
  res.json({success:true});
});
app.get('/api/admin/mpesa-logs',adminAuth,(req,res) => res.json(DB.prepare('SELECT * FROM mpesa_logs ORDER BY processedAt DESC LIMIT 100').all()));

// Profit crediting
function creditProfits() {
  const active = DB.prepare("SELECT * FROM investments WHERE status='active'").all();
  for(const inv of active){
    const nowMs=Date.now(), endMs=new Date(inv.endDate).getTime(), lastMs=new Date(inv.lastCredited||inv.startDate).getTime();
    const credit=(inv.amount*inv.roi/100/86400)*((nowMs-lastMs)/1000);
    if(nowMs>=endMs){
      const total=inv.earned+credit;
      DB.prepare("UPDATE investments SET status='completed',earned=?,lastCredited=? WHERE id=?").run(total,now(),inv.id);
      DB.prepare('UPDATE users SET balance=balance+?,totalProfits=totalProfits+? WHERE id=?').run(inv.amount+total,total,inv.userId);
      addTx(inv.userId,'profit',total,`${inv.planName} matured`);
      addNotif(inv.userId,`🎉 ${inv.planName} matured! ${kes(total)} profit credited.`,'success');
    } else {
      DB.prepare("UPDATE investments SET earned=earned+?,lastCredited=? WHERE id=?").run(credit,now(),inv.id);
    }
  }
}
creditProfits();
setInterval(creditProfits,10*60*1000);

app.listen(PORT,()=>console.log(`\n🚀 Pesa Grow running → http://localhost:${PORT}\n   Admin: admin@pesagrow.co.ke / Admin@2024\n`));
module.exports = app;
